﻿namespace Entidades;

public enum EMateria
{
    Laboratorio,
    Programacion
}